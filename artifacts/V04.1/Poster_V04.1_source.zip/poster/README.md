Shared renderer files. See [the V04.1 guide](v04_1/README.md) for fonts and build instructions.
