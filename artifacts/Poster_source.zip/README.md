# Poster source package - V04.0

Print size: 800 x 1000 mm portrait. See poster/README.md for fonts and dependencies.

The bilingual talk and Q&A are in poster/Presentation_Script_EN_ZH.md.

Rebuild from this directory:

```powershell
python -m pip install -r poster/requirements-render.txt
python scripts/build_poster.py
```

Only the current version is included. Every figure is drawn from code. The one image asset is the HKUST(GZ) mark in poster/assets, taken from the course poster template. No paid API calls are needed.
