# Poster source package - V03.2

Print size: 800 x 1000 mm portrait. See poster/README.md for fonts and dependencies.

Rebuild from this directory:

```powershell
python -m pip install -r poster/requirements-render.txt
python scripts/build_poster.py
```

Only the current version is included. No external image assets or paid API calls are needed.
