Shared renderer files. See [the V04.2 guide](v04_2/README.md) for fonts and build instructions.
