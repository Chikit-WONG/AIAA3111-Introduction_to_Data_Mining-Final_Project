Shared renderer files. See [the V04.3 guide](v04_3/README.md) for fonts and build instructions.
