# Group 11 report

**Beyond Frequent Co-Purchases: A Study of Temporal Stability in Retail Association Rules**

Chi Kit WONG (50012338), Yuxuan OUYANG (50013526), Zhicheng SUN (50012546).

## Word submission manuscript

[Report.docx](Report.docx) is the editable English final in the teaching team's Word template v2. [Report.pdf](Report.pdf) is its Microsoft Word export. The title, group and authors appear on page 1. Related Work is a separate section. The main text includes the figures and tables. Disclosures, References and the Appendix follow it.

The course template specifies A4, 2.54 cm margins, 11 pt Times New Roman body text, 1.15 line spacing and 6 pt after paragraphs. The current PDF has 12 pages. The conclusion ends on page 10 and Disclosures starts on page 11. After an edit, export the Word file and recheck these page boundaries. The submission ZIP contains the PDF from this repository.

On Windows with Microsoft Word, run the following from the adjacent [code repository](https://github.com/Chikit-WONG/AIAA3111-Introduction_to_Data_Mining-Final_Project).

```powershell
.\scripts\build_report.ps1
.\.venv\Scripts\python.exe scripts/check_report_layout.py
.\.venv\Scripts\python.exe scripts/package_submission.py
```

Word's **Save as PDF** command can also export the final. The layout checker measures the body text in the PDF. Inspect figures and captions visually after editing.

## Overleaf collaboration

The [LaTeX manuscript](main.tex) and its [section sources](sections/) remain editable in Overleaf. Select `main.tex` as the main document and compile with pdfLaTeX or XeLaTeX. The Word and LaTeX manuscripts are separate editable files. Transfer agreed content changes to the Word final before rebuilding the submission. For a local LaTeX preview, use `scripts/build_report.ps1 -Overleaf` from the code repository after installing its Tectonic helper. It writes `build/main.pdf`.

The [evidence snapshot](evidence/) and [generated tables](generated/) record the selected cohort and the results behind each figure. From the code repository, `python run.py export-report` refreshes these files and [figure assets](figures/) while preserving the Word and LaTeX manuscripts. Review both narratives when the experimental results change.

## Course submission

One member of Group 11 submits `Group_11_Project.zip` on Canvas by **11 December 2026 at 23:59 Beijing time**. The archive contains `Report.pdf`, code, a README and the instructions and checksum for downloading the public data. The Word file is also included under `report_source/`. The course excludes References, Disclosures and the Appendix from the 6–10 page main-text limit. Poster.pdf is optional for this submission.
